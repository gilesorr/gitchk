
copy (-via) testRepoMain and in the copy make the needed changes.  "Behind"
should be covered, now worry about the other statuses.

for dir in $(find  -maxdepth 1 -mindepth 1 -type d); do echo "${dir}:" ; cd "${dir}"; git status ; cd - ; done

