
This is a test repository for the https://github.com/gilesorr/gitchk
project, created 2024-11-18.  It serves no other purpose but to be cloned
and tested within the program's test framework.  It should also be
automatically deleted by the test framework, so you should never be reading
this ...

